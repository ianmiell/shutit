/* 2008-07-26 SMS.
 * VMS-specific ZLIB.H jacket header file.
 *
 * The logical name INCL_ZLIB must point to the ZLIB source directory.
 */

#include "INCL_ZLIB:ZLIB.H"
